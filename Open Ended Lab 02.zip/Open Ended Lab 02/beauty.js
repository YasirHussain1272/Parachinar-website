

///////////////////////////////////////////////////////////////////////////////////////
document.addEventListener("DOMContentLoaded", function() {
    const gallery = document.querySelector(".gallery");
    const imagePath = "image/Photo/Parachinar";
    const totalImages = 132; // Adjust this number to match the number of images you have

    for (let i = 1; i <= totalImages; i++) {
        const img = document.createElement("img");
        img.src = `${imagePath} (${i}).jpg`;
        img.alt = `Parachinar ${i}`;
        img.classList.add("thumbnail");
        gallery.appendChild(img);
    }

    const videosContainer = document.querySelector(".videos");
    const videoPath = "video/Parachinar";
    const totalVideos = 18; // Adjust this number to match the number of videos you have

    for (let i = 1; i <= totalVideos; i++) {
        const video = document.createElement("video");
        video.controls = false;
        video.classList.add("thumbnail");
        const source = document.createElement("source");
        source.src = `${videoPath} (${i}).mp4`;
        source.type = "video/mp4";
        video.appendChild(source);
        videosContainer.appendChild(video);
    }

    const modal = document.getElementById("modal");
    const modalImage = document.getElementById("modalImage");
    const modalVideo = document.getElementById("modalVideo");
    const modalVideoSource = document.getElementById("modalVideoSource");
    const captionText = document.getElementById("caption");
    const close = document.querySelector(".close");

    document.querySelectorAll(".gallery img").forEach(img => {
        img.onclick = function() {
            modal.style.display = "block";
            modalImage.src = this.src;
            modalImage.style.display = "block";
            modalVideo.style.display = "none";
            captionText.innerHTML = this.alt;
        }
    });

    document.querySelectorAll(".videos video").forEach(video => {
        video.onclick = function() {
            modal.style.display = "block";
            modalVideoSource.src = this.querySelector("source").src;
            modalVideo.load();
            modalVideo.style.display = "block";
            modalImage.style.display = "none";
            captionText.innerHTML = this.alt;
        }
    });

    close.onclick = function() {
        modal.style.display = "none";
        modalVideo.pause();
    }

    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
            modalVideo.pause();
        }
    }
});
