function login() {
    var storedUsername = localStorage.getItem("username");
    var storedPassword = localStorage.getItem("password");
    var enteredUsername = document.getElementById("username").value;
    var enteredPassword = document.getElementById("password").value;

    if (enteredUsername === storedUsername && enteredPassword === storedPassword) {
        document.getElementById("modalMessage").textContent = "Login Successful!";
        document.getElementById("successModal").style.display = "block";
        setTimeout(function() {
            window.location.href = "home.html";
        }, 2000);
    } else {
        alert("Invalid username or password.");
    }
}

function closeModal() {
    document.getElementById("successModal").style.display = "none";
}
