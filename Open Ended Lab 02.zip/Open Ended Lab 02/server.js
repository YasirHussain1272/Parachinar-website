const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const xlsx = require('xlsx');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Utility functions
const readExcelFile = (filePath) => {
    const file = xlsx.readFile(filePath);
    const sheetName = file.SheetNames[0];
    return xlsx.utils.sheet_to_json(file.Sheets[sheetName]);
};

const writeExcelFile = (filePath, data) => {
    const newSheet = xlsx.utils.json_to_sheet(data);
    const newBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(newBook, newSheet, 'Sheet1');
    xlsx.writeFile(newBook, filePath);
};

// Path to the Excel file
const excelFilePath = 'users.xlsx';

// Ensure the Excel file exists
if (!fs.existsSync(excelFilePath)) {
    writeExcelFile(excelFilePath, []);
}

// Serve the main HTML file on root request
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'));
});

// Registration endpoint
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const users = readExcelFile(excelFilePath);

    if (users.find(user => user.username === username)) {
        return res.status(400).json({ message: 'Username already exists' });
    }

    users.push({ username, password });
    writeExcelFile(excelFilePath, users);

    res.status(201).json({ message: 'Registration successful' });
});

// Login endpoint
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = readExcelFile(excelFilePath);

    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
        return res.status(200).json({ message: 'Login successful' });
    }

    res.status(401).json({ message: 'Invalid username or password' });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
